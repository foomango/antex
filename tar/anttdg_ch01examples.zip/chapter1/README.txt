This directory contains the example from Chapter 1.
The Java files are dummy classes that don't really
do anything. The buildfile is the one shown in Example 1-1.
