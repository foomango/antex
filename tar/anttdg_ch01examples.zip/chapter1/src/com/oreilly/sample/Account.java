package com.oreilly.sample;

/**
 * A dummy class for example purposes only.
 */
public class Account {
    private String number;

    public Account(String number) {
        this.number = number;
    }

    public String getNumber() {
        return this.number;
    }
}

