package com.oreilly.sample;

/**
 * A dummy class for example purposes only.
 */
public class Person {
    private String name;

    public Person(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }
}

