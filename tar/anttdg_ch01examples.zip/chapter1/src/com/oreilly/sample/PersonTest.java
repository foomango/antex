package com.oreilly.sample;

/**
 * A dummy class for example purposes only.
 */
public class PersonTest {
}

