This directory contains the exact version irssibot used
as the basis for the buildfile example in Chapter 3 of 
Ant: The Definitive Guide. This directory also contains
the buildfile shown in Example 3-1. 

Please note that we distribute this version of irssibot
only to make it easy for you to follow along with the 
example in Chapter 3 of the Ant book. Our example 
buildfile may not be compatible with subsequent verions.
If you wish to actually use irssibot, we recommend that 
you download the latest release from the following URL:

     http://dreamland.tky.hut.fi/IrssiBot/

